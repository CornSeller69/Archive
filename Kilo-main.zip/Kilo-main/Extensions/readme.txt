This folder is where extensions are meant to be put in.
It will now be a standard directory for extensions in my projects.

Sincerely, CornSeller.