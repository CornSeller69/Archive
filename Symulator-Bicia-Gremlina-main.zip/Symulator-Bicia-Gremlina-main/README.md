# Symulator Bicia Gremlina
Prosta symulacja bicia jakiegoś żula, który ciebie wkurwia!!!!

Projekt wytworzony z nudy

Ciekawostka:
Nie ma pliku .js a cały skrypt zawarty jest w pliku .html pod <script>, jest to dlatego, że JavaScript dostaje dałna i w odrębnym pliku... nie działa...
