# Kilo

This is a very barebone and simple game of Kilo.

>[!TIP]
>Kilo is basically Hi-Lo on forced starvation; you just score points by choosing higher or lower,<br>hoping that dealer will indeed put down a card that's either higher or lower than the one already laying down.<br>If Dealer's card is the opposite of chosen, you lose (your score is back at zero, and that's it).
